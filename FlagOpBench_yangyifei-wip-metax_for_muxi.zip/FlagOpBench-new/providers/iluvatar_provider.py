"""Iluvatar Provider

天数智芯平台性能基线Provider。

Corex 通过 torch.cuda 暴露设备。本机常见两套环境：
- corex_vllm_plugin：vllm 能 import，但 cuda 常 Error 1001
- corex 基座镜像：cuda 可用，但 import vllm 常因 ixformer
  undefined symbol（cuInferPagedAttention）失败

因此继承 NvidiaProvider；setup 宽捕获 vllm 失败；
swiglu 在缺少 torch.ops._C.silu_and_mul 时回退到
F.silu * mul（老师口径：缺的算子可从 torch 找）。
"""
import torch
import torch.nn.functional as F

from .nvidia_provider import NvidiaProvider
from .registry import register_provider


@register_provider("iluvatar", platform="iluvatar", is_default=True)
class IluvatarProvider(NvidiaProvider):
    """天数智芯平台算子实现加载器（Corex / torch 兜底）"""

    @property
    def name(self) -> str:
        return "iluvatar"

    @property
    def platform(self) -> str:
        return "iluvatar"

    def get_device(self) -> torch.device:
        return torch.device("cuda:0")

    def synchronize(self) -> None:
        torch.cuda.synchronize()

    def is_available(self) -> bool:
        return torch.cuda.is_available()

    def setup(self):
        if not torch.cuda.is_available():
            print("  [WARN] torch.cuda.is_available()=False; "
                  "check IX_VISIBLE_DEVICES / Corex driver-SDK match "
                  "(vllm plugin image often Error 1001)")

        try:
            import vllm
            self._vllm = vllm
            print(f"  Loaded vllm: {vllm.__version__ if hasattr(vllm, '__version__') else 'unknown'}")
        except Exception as e:
            print(f"  [WARN] Failed to import vllm: {type(e).__name__}: {e}")
            self._vllm = None
            self._vllm_ops = None
            self._vllm_v1_ops = None
            self._vllm_mhc = None
            self._vllm_sparse_attn = None
            self._vllm_fused_moe = None
            self._vllm_flash_attn = None
            self._torch_ops_registered = (
                hasattr(torch.ops, "_C")
                and hasattr(torch.ops._C, "silu_and_mul")
            )
            print(f"  Loaded vllm modules: _custom_ops=False, v1_ops=False, "
                  f"mhc=False, flash_attn=False, "
                  f"torch_ops._C.silu_and_mul={self._torch_ops_registered}")
            return

        try:
            from vllm import _custom_ops
            self._vllm_ops = _custom_ops
        except Exception as e:
            print(f"  [WARN] Failed to import vllm._custom_ops: {type(e).__name__}: {e}")
            self._vllm_ops = None

        try:
            from vllm.v1.attention.ops import deepseek_v4_ops, flashmla
            self._vllm_v1_ops = {
                "deepseek_v4": deepseek_v4_ops,
                "flashmla": flashmla,
            }
        except Exception as e:
            print(f"  [WARN] Failed to import v1 ops: {type(e).__name__}: {e}")
            self._vllm_v1_ops = None

        try:
            from vllm.model_executor.layers import mhc, sparse_attn_indexer
            from vllm.model_executor.layers.fused_moe import fused_moe as fused_moe_module
            self._vllm_mhc = mhc
            self._vllm_sparse_attn = sparse_attn_indexer
            self._vllm_fused_moe = fused_moe_module
        except Exception as e:
            print(f"  [WARN] Failed to import model_executor layers: {type(e).__name__}: {e}")
            self._vllm_mhc = None
            self._vllm_sparse_attn = None
            self._vllm_fused_moe = None

        try:
            from vllm.vllm_flash_attn import flash_attn_interface
            self._vllm_flash_attn = flash_attn_interface
        except Exception as e:
            print(f"  [WARN] Failed to import flash_attn: {type(e).__name__}: {e}")
            self._vllm_flash_attn = None

        self._torch_ops_registered = (
            hasattr(torch.ops, "_C")
            and hasattr(torch.ops._C, "silu_and_mul")
        )
        if not self._torch_ops_registered:
            print("  [WARN] torch.ops._C.silu_and_mul unavailable; "
                  "swiglu will use torch fallback if requested")

        print(f"  Loaded vllm modules: _custom_ops={self._vllm_ops is not None}, "
              f"v1_ops={self._vllm_v1_ops is not None}, "
              f"mhc={self._vllm_mhc is not None}, "
              f"flash_attn={self._vllm_flash_attn is not None}, "
              f"torch_ops._C.silu_and_mul={self._torch_ops_registered}")

    def _load_swiglu(self):
        """优先 torch.ops._C.silu_and_mul；天数 corex 常无该符号 → F.silu * mul"""
        if hasattr(torch.ops, "_C") and hasattr(torch.ops._C, "silu_and_mul"):
            return super()._load_swiglu()

        def wrapper(input_tensor, **kwargs):
            d = input_tensor.shape[-1] // 2
            x = input_tensor[..., :d]
            y = input_tensor[..., d:]
            return F.silu(x) * y

        return wrapper, {
            "source": "torch.nn.functional.silu * mul (fallback)",
            "type": "torch",
            "platform": "iluvatar",
        }

    def get_impl(self, op_name, operator):
        impl_fn, impl_info = super().get_impl(op_name, operator)
        if impl_fn is not None:
            impl_info = {**impl_info, "platform": "iluvatar"}
        return impl_fn, impl_info
